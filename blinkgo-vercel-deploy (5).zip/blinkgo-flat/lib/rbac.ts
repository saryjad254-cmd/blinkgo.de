import { redirect } from 'next/navigation';
import { createServerClient } from '@/lib/supabase/server';

export type UserRole = 'customer' | 'driver' | 'restaurant' | 'admin';

export interface CurrentUser {
  id: string;
  email: string | null;
  role: UserRole;
  name: string;
}

/**
 * الحصول على المستخدم الحالي مع التحقق من تسجيل الدخول.
 * يحوّل إلى /login إذا لم يكن مسجلاً.
 */
export async function requireUser(): Promise<CurrentUser> {
  const supabase = createServerClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  const { data: userData, error } = await supabase
    .from('users')
    .select('id, email, role, name')
    .eq('id', user.id)
    .single();

  if (error || !userData) {
    redirect('/login');
  }

  return userData as CurrentUser;
}

/**
 * التحقق من أن المستخدم لديه الدور المطلوب.
 */
export async function requireRole(role: UserRole | UserRole[]): Promise<CurrentUser> {
  const user = await requireUser();
  const allowed = Array.isArray(role) ? role : [role];
  if (!allowed.includes(user.role)) {
    redirect('/login?error=unauthorized');
  }
  return user;
}

/**
 * الحصول على المستخدم الحالي بدون إعادة توجيه (للصفحات العامة).
 */
export async function getCurrentUser(): Promise<CurrentUser | null> {
  try {
    const supabase = createServerClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data: userData } = await supabase
      .from('users')
      .select('id, email, role, name')
      .eq('id', user.id)
      .single();

    return userData as CurrentUser | null;
  } catch {
    return null;
  }
}