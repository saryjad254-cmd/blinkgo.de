'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Check, Loader2 } from 'lucide-react';
import { createBrowserClient } from '@/lib/supabase/client';
import type { OrderStatus } from '@/lib/types';

interface Props {
  orderId: string;
  currentStatus: OrderStatus;
}

const ACTION_MAP: Partial<Record<OrderStatus, { next: OrderStatus; label: string; className: string }>> = {
  assigned: { next: 'picked_up', label: 'استلمت الطلب', className: 'bg-brand text-white' },
  picked_up: { next: 'delivering', label: 'بدأت التوصيل', className: 'bg-brand text-white' },
  delivering: { next: 'delivered', label: 'تم التسليم', className: 'bg-green-600 text-white' },
  ready: { next: 'picked_up', label: 'استلمت من المطعم', className: 'bg-brand text-white' },
};

export function OrderActions({ orderId, currentStatus }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const action = ACTION_MAP[currentStatus];

  async function handleAction() {
    if (!action) return;
    setLoading(true);
    setError(null);
    try {
      const supabase = createBrowserClient();
      const { error: rpcError } = await supabase.rpc('update_order_status', {
        p_order_id: orderId,
        p_new_status: action.next,
      });
      if (rpcError) throw rpcError;
      router.refresh();
    } catch (err: any) {
      setError(err.message ?? 'فشل تحديث الحالة');
    } finally {
      setLoading(false);
    }
  }

  if (!action) {
    return null;
  }

  return (
    <div className="space-y-3">
      {error && (
        <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">
          {error}
        </div>
      )}
      <button
        onClick={handleAction}
        disabled={loading}
        className={`w-full py-4 rounded-xl font-bold text-base transition-colors disabled:opacity-50 flex items-center justify-center gap-2 ${action.className}`}
      >
        {loading ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            جارٍ التحديث...
          </>
        ) : (
          <>
            <Check className="w-5 h-5" />
            {action.label}
          </>
        )}
      </button>
    </div>
  );
}