'use client';

import { useEffect, useState } from 'react';
import { Power, Loader2 } from 'lucide-react';
import { createBrowserClient } from '@/lib/supabase/client';

export function OnlineToggle({ initialOnline = false }: { initialOnline?: boolean }) {
  const [online, setOnline] = useState(initialOnline);
  const [loading, setLoading] = useState(false);

  async function toggle() {
    setLoading(true);
    try {
      const supabase = createBrowserClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('غير مسجل');

      // upsert على driver_status
      const { error } = await supabase
        .from('driver_status')
        .upsert({
          driver_id: user.id,
          is_online: !online,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'driver_id',
        });

      if (error) throw error;
      setOnline(!online);
    } catch (err: any) {
      alert(err.message ?? 'فشل تغيير الحالة');
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      onClick={toggle}
      disabled={loading}
      className={`relative w-full p-6 rounded-2xl font-bold text-lg transition-all ${
        online
          ? 'bg-gradient-to-br from-green-500 to-green-600 text-white shadow-lg shadow-green-200'
          : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-gray-400'
      }`}
    >
      <div className="flex items-center justify-center gap-3">
        {loading ? (
          <Loader2 className="w-6 h-6 animate-spin" />
        ) : (
          <Power className={`w-6 h-6 ${online ? '' : 'text-gray-400'}`} />
        )}
        <span>{online ? 'متصل — تستقبل طلبات' : 'غير متصل'}</span>
      </div>
      <div className={`mt-2 text-sm font-normal ${online ? 'text-green-50' : 'text-gray-500'}`}>
        اضغط لتغيير الحالة
      </div>
    </button>
  );
}