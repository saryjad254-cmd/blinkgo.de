'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Truck, ListChecks, Wallet } from 'lucide-react';

export function DriverNav() {
  const pathname = usePathname();

  const links = [
    { href: '/driver/dashboard', label: 'الرئيسية', icon: Truck },
    { href: '/driver/orders', label: 'الطلبات', icon: ListChecks },
    { href: '/driver/earnings', label: 'الأرباح', icon: Wallet },
  ];

  return (
    <>
      {/* Desktop */}
      <nav className="hidden md:block bg-white border-b border-gray-200 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/driver/dashboard" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-brand text-white flex items-center justify-center font-bold">
                🚗
              </div>
              <span className="font-bold text-lg text-gray-900">BlinkGo Driver</span>
            </Link>
            <div className="flex items-center gap-1">
              {links.map((l) => {
                const Icon = l.icon;
                const active = pathname === l.href;
                return (
                  <Link
                    key={l.href}
                    href={l.href}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      active ? 'bg-brand text-white' : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {l.label}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 bg-white border-t border-gray-200 z-30 shadow-lg">
        <div className="grid grid-cols-3 max-w-md mx-auto">
          {links.map((l) => {
            const Icon = l.icon;
            const active = pathname === l.href;
            return (
              <Link
                key={l.href}
                href={l.href}
                className={`flex flex-col items-center justify-center py-3 ${
                  active ? 'text-brand' : 'text-gray-500'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs mt-1 font-medium">{l.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
}