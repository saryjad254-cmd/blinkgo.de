import { ORDER_STATUS_COLORS, ORDER_STATUS_LABELS, type OrderStatus } from '@/lib/types';

export function StatusBadge({ status }: { status: OrderStatus }) {
  return (
    <span className={ORDER_STATUS_COLORS[status] || 'badge'}>
      {ORDER_STATUS_LABELS[status] || status}
    </span>
  );
}