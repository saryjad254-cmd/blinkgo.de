'use client';

import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { ChefHat, ArrowRight } from 'lucide-react';
import type { UserRole } from '@/lib/types';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  back?: boolean;
  action?: React.ReactNode;
  role?: UserRole;
}

export function PageHeader({ title, subtitle, back, action, role }: PageHeaderProps) {
  const router = useRouter();

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            {back && (
              <button
                onClick={() => router.back()}
                className="p-2 -m-2 text-gray-600 hover:text-gray-900"
                aria-label="رجوع"
              >
                <ArrowRight className="w-5 h-5" />
              </button>
            )}
            {!back && (
              <Link href="/" className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-brand text-white flex items-center justify-center">
                  <ChefHat className="w-5 h-5" />
                </div>
                <span className="font-bold text-gray-900 hidden sm:inline">BlinkGo</span>
              </Link>
            )}
            <div className="min-w-0">
              <h1 className="text-lg sm:text-xl font-bold text-gray-900 truncate">
                {title}
              </h1>
              {subtitle && (
                <p className="text-xs sm:text-sm text-gray-500 truncate">{subtitle}</p>
              )}
            </div>
          </div>
          {action && <div className="flex items-center gap-2">{action}</div>}
        </div>
      </div>
    </header>
  );
}