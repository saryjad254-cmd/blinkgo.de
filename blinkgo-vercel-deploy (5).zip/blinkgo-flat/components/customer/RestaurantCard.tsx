import Link from 'next/link';
import { Star, Clock, Truck, ChefHat } from 'lucide-react';
import type { Restaurant } from '@/lib/types';

export function RestaurantCard({ restaurant }: { restaurant: Restaurant }) {
  return (
    <Link
      href={`/restaurants/${restaurant.id}`}
      className="block bg-white rounded-2xl overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow"
    >
      {/* Cover */}
      <div className="relative h-40 sm:h-48 bg-gradient-to-br from-orange-100 to-orange-50">
        {restaurant.cover_url ? (
          <img
            src={restaurant.cover_url}
            alt={restaurant.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <ChefHat className="w-12 h-12 text-brand opacity-40" />
          </div>
        )}
        {restaurant.is_featured && (
          <span className="absolute top-3 right-3 bg-brand text-white text-xs px-2 py-1 rounded-full font-bold">
            مميز
          </span>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-bold text-gray-900 text-base truncate flex-1">
            {restaurant.name}
          </h3>
          <div className="flex items-center gap-1 text-sm font-bold text-gray-900 flex-shrink-0">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            {Number(restaurant.rating || 0).toFixed(1)}
          </div>
        </div>

        {restaurant.description && (
          <p className="text-xs text-gray-500 line-clamp-2 mb-3">
            {restaurant.description}
          </p>
        )}

        {restaurant.cuisine?.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {restaurant.cuisine.slice(0, 3).map((c) => (
              <span key={c} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                {c}
              </span>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between text-xs text-gray-600 pt-3 border-t border-gray-100">
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            <span>{restaurant.estimated_delivery_time}</span>
          </div>
          <div className="flex items-center gap-1">
            <Truck className="w-3.5 h-3.5" />
            <span>{restaurant.delivery_fee} ر.س</span>
          </div>
          <div className="text-gray-500">
            {restaurant.review_count} تقييم
          </div>
        </div>
      </div>
    </Link>
  );
}