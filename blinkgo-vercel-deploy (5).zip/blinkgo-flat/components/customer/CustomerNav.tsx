'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Store, ShoppingBag, ShoppingCart, User as UserIcon } from 'lucide-react';
import { useCart } from '@/lib/cart-store';

export function CustomerNav() {
  const pathname = usePathname();
  const itemCount = useCart((s) => s.items.reduce((sum, i) => sum + i.quantity, 0));

  const links = [
    { href: '/restaurants', label: 'المطاعم', icon: Store },
    { href: '/orders', label: 'طلباتي', icon: ShoppingBag },
    { href: '/cart', label: 'السلة', icon: ShoppingCart, badge: itemCount },
  ];

  return (
    <>
      {/* Desktop top nav */}
      <nav className="hidden md:block bg-white border-b border-gray-200 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/restaurants" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-brand text-white flex items-center justify-center font-bold">
                B
              </div>
              <span className="font-bold text-lg text-gray-900">BlinkGo</span>
            </Link>
            <div className="flex items-center gap-1">
              {links.map((l) => {
                const Icon = l.icon;
                const active = pathname === l.href || pathname.startsWith(`${l.href}/`);
                return (
                  <Link
                    key={l.href}
                    href={l.href}
                    className={`relative flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      active ? 'bg-brand text-white' : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {l.label}
                    {!!l.badge && l.badge > 0 && (
                      <span
                        className={`absolute -top-1 -left-1 min-w-[20px] h-5 px-1.5 rounded-full text-xs flex items-center justify-center font-bold ${
                          active ? 'bg-white text-brand' : 'bg-brand text-white'
                        }`}
                      >
                        {l.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 bg-white border-t border-gray-200 z-30 shadow-lg">
        <div className="grid grid-cols-3 max-w-md mx-auto">
          {links.map((l) => {
            const Icon = l.icon;
            const active = pathname === l.href || pathname.startsWith(`${l.href}/`);
            return (
              <Link
                key={l.href}
                href={l.href}
                className={`relative flex flex-col items-center justify-center py-3 transition-colors ${
                  active ? 'text-brand' : 'text-gray-500'
                }`}
              >
                <Icon className={`w-5 h-5 ${active ? 'fill-current' : ''}`} />
                <span className="text-xs mt-1 font-medium">{l.label}</span>
                {!!l.badge && l.badge > 0 && (
                  <span className="absolute top-1 right-1/2 translate-x-3 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center font-bold">
                    {l.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
}