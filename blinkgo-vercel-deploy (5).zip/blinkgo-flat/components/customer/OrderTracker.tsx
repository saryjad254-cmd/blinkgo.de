'use client';

import { useEffect, useState } from 'react';
import { Check, Clock, ChefHat, Truck, PackageCheck, MapPin } from 'lucide-react';
import { StatusBadge } from '@/components/shared/StatusBadge';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import type { Order, OrderStatus } from '@/lib/types';

const TRACKER_STEPS: Array<{
  status: OrderStatus;
  label: string;
  icon: typeof Clock;
  description: string;
}> = [
  { status: 'pending', label: 'تم الاستلام', icon: Clock, description: 'في انتظار تأكيد المطعم' },
  { status: 'confirmed', label: 'مؤكد', icon: Check, description: 'المطعم استلم طلبك' },
  { status: 'preparing', label: 'قيد التحضير', icon: ChefHat, description: 'الطاهي يحضّر طعامك' },
  { status: 'ready', label: 'جاهز', icon: PackageCheck, description: 'جاهز لاستلام السائق' },
  { status: 'delivering', label: 'في الطريق', icon: Truck, description: 'السائق في طريقه إليك' },
  { status: 'delivered', label: 'تم التسليم', icon: MapPin, description: 'وصل!' },
];

export function OrderTracker({ initialOrder }: { initialOrder: Order }) {
  const [order, setOrder] = useState<Order>(initialOrder);

  // Realtime subscription
  useEffect(() => {
    let mounted = true;
    const poll = async () => {
      try {
        const { createBrowserClient } = await import('@/lib/supabase/client');
        const supabase = createBrowserClient();
        const { data } = await supabase
          .from('orders')
          .select('*')
          .eq('id', initialOrder.id)
          .single();
        if (mounted && data) setOrder(data as Order);
      } catch (e) {
        // ignore
      }
    };
    const t = setInterval(poll, 10_000);
    return () => {
      mounted = false;
      clearInterval(t);
    };
  }, [initialOrder.id]);

  const currentStepIndex = TRACKER_STEPS.findIndex((s) => s.status === order.status);

  if (order.status === 'cancelled' || order.status === 'refunded') {
    return (
      <div className="card text-center">
        <StatusBadge status={order.status} />
        <p className="text-sm text-gray-600 mt-3">
          {order.status === 'cancelled' ? 'تم إلغاء الطلب' : 'تم استرداد الطلب'}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Progress bar */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-gray-900">حالة الطلب</h2>
          <StatusBadge status={order.status} />
        </div>

        <div className="space-y-4">
          {TRACKER_STEPS.map((step, idx) => {
            const Icon = step.icon;
            const done = idx <= currentStepIndex;
            const current = idx === currentStepIndex;
            return (
              <div key={step.status} className="flex items-start gap-3 relative">
                {idx < TRACKER_STEPS.length - 1 && (
                  <div
                    className={`absolute right-[19px] top-10 w-0.5 h-8 ${
                      done ? 'bg-brand' : 'bg-gray-200'
                    }`}
                  />
                )}
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                    done
                      ? 'bg-brand text-white'
                      : 'bg-gray-100 text-gray-400'
                  } ${current ? 'ring-4 ring-orange-100' : ''}`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 pt-1">
                  <p
                    className={`font-medium ${
                      done ? 'text-gray-900' : 'text-gray-400'
                    }`}
                  >
                    {step.label}
                  </p>
                  <p className="text-xs text-gray-500 mt-0.5">{step.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}