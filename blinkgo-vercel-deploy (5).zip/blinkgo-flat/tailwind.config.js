/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fef3e2',
          100: '#fde2b8',
          200: '#fbcb87',
          300: '#f9b355',
          400: '#f79b24',
          500: '#dd820b',
          600: '#ac6608',
          700: '#7a4906',
          800: '#482c03',
          900: '#170f01',
        },
        brand: {
          DEFAULT: '#f79b24',
          dark: '#dd820b',
        },
      },
      fontFamily: {
        arabic: ['Cairo', 'Tajawal', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};