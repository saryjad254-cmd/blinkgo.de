import { NextResponse, type NextRequest } from 'next/server';
import { updateSession } from '@/lib/supabase/middleware';

const PUBLIC_PATHS = ['/', '/login', '/api/health'];

export async function middleware(request: NextRequest) {
  const { response, user } = await updateSession(request);
  const path = request.nextUrl.pathname;

  // الراوتات العامة
  if (PUBLIC_PATHS.some((p) => path === p || path.startsWith(`${p}/`))) {
    return response;
  }

  // يحتاج تسجيل دخول
  const protectedPrefixes = [
    '/dashboard', '/users', '/restaurants', '/drivers', '/analytics',
    '/cart', '/orders',
    '/driver',
  ];

  if (protectedPrefixes.some((p) => path.startsWith(p))) {
    if (!user) {
      const url = request.nextUrl.clone();
      url.pathname = '/login';
      url.searchParams.set('redirect', path);
      return NextResponse.redirect(url);
    }
  }

  return response;
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};