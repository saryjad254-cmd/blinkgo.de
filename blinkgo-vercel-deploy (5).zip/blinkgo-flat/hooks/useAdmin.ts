'use client';

import { useQuery } from '@tanstack/react-query';
import { createBrowserClient } from '@/lib/supabase/client';

export interface AdminStats {
  total_users: number;
  total_customers: number;
  total_drivers: number;
  total_restaurants: number;
  active_restaurants: number;
  total_orders: number;
  orders_today: number;
  orders_pending: number;
  orders_delivering: number;
  revenue_today: number;
  revenue_total: number;
  online_drivers: number;
}

export function useAdminStats() {
  const supabase = createBrowserClient();
  return useQuery({
    queryKey: ['admin-stats'],
    queryFn: async (): Promise<AdminStats | null> => {
      const { data, error } = await supabase.rpc('get_admin_stats');
      if (error) {
        console.error('useAdminStats error:', error);
        return null;
      }
      return data as AdminStats;
    },
    refetchInterval: 30 * 1000,
  });
}

export function useUsers(filter?: { role?: string; isActive?: boolean }) {
  const supabase = createBrowserClient();
  return useQuery({
    queryKey: ['users', filter],
    queryFn: async () => {
      let query = supabase
        .from('users')
        .select('id, email, name, role, is_active, is_verified, created_at, last_login_at')
        .order('created_at', { ascending: false })
        .limit(100);
      if (filter?.role) query = query.eq('role', filter.role);
      if (filter?.isActive !== undefined) query = query.eq('is_active', filter.isActive);
      const { data, error } = await query;
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function useRestaurants() {
  const supabase = createBrowserClient();
  return useQuery({
    queryKey: ['restaurants'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('restaurants')
        .select('*')
        .order('rating', { ascending: false })
        .limit(100);
      if (error) throw error;
      return data ?? [];
    },
    refetchInterval: 60 * 1000,
  });
}

export function useDrivers() {
  const supabase = createBrowserClient();
  return useQuery({
    queryKey: ['drivers'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('users')
        .select(`
          id, name, email, is_active, last_login_at,
          driver_status:driver_status (is_online, is_on_delivery, latitude, longitude)
        `)
        .eq('role', 'driver')
        .limit(100);
      if (error) throw error;
      return data ?? [];
    },
    refetchInterval: 30 * 1000,
  });
}

export function useRecentOrders(limit = 20) {
  const supabase = createBrowserClient();
  return useQuery({
    queryKey: ['recent-orders', limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          id, order_number, status, total, payment_status, created_at,
          restaurants (name),
          customer:customer_id (name)
        `)
        .order('created_at', { ascending: false })
        .limit(limit);
      if (error) throw error;
      return data ?? [];
    },
    refetchInterval: 15 * 1000,
  });
}