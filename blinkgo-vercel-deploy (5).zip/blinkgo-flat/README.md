# BlinkGo — Full Stack Food Delivery Platform

> منصة توصيل طعام كاملة — جاهزة للنشر على Vercel **مباشرة** عبر drag & drop.

## 🎯 نظرة سريعة

| الواجهة | الـ Path | الدور |
|---|---|---|
| 🌐 صفحة الهبوط | `/` | الكل |
| 🔐 تسجيل الدخول | `/login` | الكل |
| 👤 لوحة الزبون | `/restaurants`, `/cart`, `/orders` | `customer` |
| 🚗 لوحة السائق | `/driver/dashboard`, `/driver/orders`, `/driver/earnings` | `driver` |
| ⚙️ لوحة الإدارة | `/dashboard`, `/users`, `/restaurants`, `/drivers`, `/analytics` | `admin` |

## 📦 البنية (مسطّحة — بدون monorepo)

```
blinkgo-flat/
├── app/                                ← Next.js 14 App Router
│   ├── layout.tsx                      ← Root layout (Cairo font + RTL)
│   ├── page.tsx                        ← Landing + توجيه ذكي حسب الدور
│   ├── globals.css                     ← Tailwind + styles
│   ├── (auth)/login/page.tsx           ← تسجيل دخول ذكي
│   ├── (admin)/                        ← 5 صفحات + layout
│   ├── (customer)/                     ← 5 صفحات + layout 🛒
│   ├── (driver)/                       ← 4 صفحات + layout 🚗
│   └── api/health/route.ts             ← Health check
├── components/                         ← 14 مكون
│   ├── QueryProvider.tsx
│   ├── AdminLayout.tsx
│   ├── customer/   (4)
│   ├── driver/     (4)
│   ├── shared/     (4)
│   └── ui/         (2)
├── hooks/useAdmin.ts
├── lib/                                ← 6 ملفات
│   ├── supabase/    (client, server, middleware)
│   ├── cart-store.ts (Zustand + persist)
│   ├── rbac.ts
│   └── types.ts
├── deploy/supabase/                    ← 4 ملفات SQL
├── public/                             ← Static assets
├── middleware.ts                       ← حماية الراوتات
├── .env.example
├── .gitignore
├── next.config.js
├── package.json
├── postcss.config.js
├── tailwind.config.js
├── tsconfig.json
├── vercel.json                         ← iad1 region
├── env.example
└── README.md
```

## 🚀 النشر على Vercel — بدون Git (drag & drop)

### الطريقة الأسهل:

1. في Vercel Dashboard: https://vercel.com/new
2. اضغط **"Add files via upload"** أو اسحب الـ ZIP مباشرة
3. **لا حاجة** لتحديد Root Directory — كل شيء في الجذر ✅
4. اضغط **Deploy**

### Environment Variables المطلوبة:

```
NEXT_PUBLIC_SUPABASE_URL     = https://rhdaffhlrglyknxtucux.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = <من Supabase Dashboard>
SUPABASE_SERVICE_ROLE_KEY     = <من Supabase Dashboard>
NEXT_PUBLIC_APP_URL           = https://your-app.vercel.app
NEXT_TELEMETRY_DISABLED       = 1
```

## 🚀 النشر عبر GitHub (اختياري)

```bash
# 1. init + commit
git init
git add .
git commit -m "Initial BlinkGo deploy"

# 2. ادفع لـ GitHub
git remote add origin https://github.com/saryjad254/blinkgo.git
git push -u origin main

# 3. في Vercel: Import المشروع
#    - Framework: Next.js (تلقائي)
#    - Root Directory: اتركه فارغ (كل شيء في الجذر)
#    - Deploy
```

## 🗄️ Supabase Setup (مرة واحدة)

في **Supabase SQL Editor**، نفّذ بالترتيب:

```
deploy/supabase/00-auth-sync.sql      ← 3 Triggers + إصلاح auth_role()
deploy/supabase/01-rls-fixes.sql      ← 31 RLS Policy
deploy/supabase/02-aggregations.sql   ← 4 Triggers تلقائية
deploy/supabase/03-helpers.sql        ← 4 RPC functions
```

## 🧪 التشغيل المحلي

```bash
# 1. ثبّت
npm install

# 2. Env
cp .env.example .env.local
# عدّل بالقيم الحقيقية

# 3. شغّل
npm run dev
# → http://localhost:3000
```

## 🎯 حساب تجريبي

| Email | Password | Role |
|---|---|---|
| `admin@blinkgo.com` | `DemoAdmin!2024` | admin |
| `demo@blinkgo.com` | `DemoCustomer!2024` | customer |
| `driver@blinkgo.com` | `DemoDriver!2024` | driver |

## 🐛 Troubleshooting

| المشكلة | الحل |
|---|---|
| `Module not found` | تأكد كل الـ files في الجذر |
| `Invalid vercel.json` | تحقق أن JSON صحيح بدون تعليقات |
| `permission denied for table` | شغّل `01-rls-fixes.sql` |
| Routes لا تعمل | تأكد من الأقواس `(admin)` `(customer)` إلخ |

## 📄 الترخيص

Private — جميع الحقوق محفوظة.